# LIBRERIAS
import json
from django.http import JsonResponse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.forms.models import model_to_dict
from .models import Proyecto


# VISTA
@method_decorator(csrf_exempt, name="dispatch")
class ProyectoView(View):

    def get(self, request, pk=None):
        if pk is None:
            return JsonResponse(list(Proyecto.objects.values()), safe=False)
        try:
            proyecto = Proyecto.objects.get(pk=pk)
        except Proyecto.DoesNotExist:
            return JsonResponse({"error": "No encontrado"}, status=404)
        return JsonResponse(model_to_dict(proyecto))

    def post(self, request):
        try:
            datos = json.loads(request.body)
            proyecto = Proyecto.objects.create(
                nombre=datos["nombre"],
                descripcion=datos.get("descripcion", ""),
            )
        except (json.JSONDecodeError, KeyError):
            return JsonResponse({"error": "Datos inválidos"}, status=400)
        return JsonResponse(model_to_dict(proyecto), status=201)

    def put(self, request, pk):
        try:
            proyecto = Proyecto.objects.get(pk=pk)
            datos = json.loads(request.body)
        except Proyecto.DoesNotExist:
            return JsonResponse({"error": "No encontrado"}, status=404)
        except json.JSONDecodeError:
            return JsonResponse({"error": "JSON inválido"}, status=400)
        proyecto.nombre = datos.get("nombre", proyecto.nombre)
        proyecto.descripcion = datos.get("descripcion", proyecto.descripcion)
        proyecto.save()
        return JsonResponse(model_to_dict(proyecto))

    def delete(self, request, pk):
        try:
            proyecto = Proyecto.objects.get(pk=pk)
        except Proyecto.DoesNotExist:
            return JsonResponse({"error": "No encontrado"}, status=404)
        proyecto.delete()
        return JsonResponse({"mensaje": "Eliminado"})